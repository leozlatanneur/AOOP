/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagementsystem;

/**
 *
 * @author 136201
 */
public class Patient {
    private String name;
    private int age;

    // Constructor for Patient class
    public Patient(String name) {
        this.name = name;
    }

    // Method to set the age of the patient
    public void setAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 130) {
            throw new InvalidAgeException("Invalid age: " + age + ". Age must be between 0 and 130.");
        }
        this.age = age;
    }

    @Override
    public String toString() {
        return "Patient{name='" + name + '\'' + ", age=" + age + '}';
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagementsystem;

/**
 *
 * @author 136201
 */
public class InvalidAgeException {
    public InvalidAgeException(String message) {
        super(message);
    }
}



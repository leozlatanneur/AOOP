package schoolmanagementsystem;

 
import java.util.ArrayList;
import java.util.List;




public class SchoolManagementSystem {
    
    // Inner class to represent a student's grade
    static class Grade {
        String studentName;
        int grade;
        
        Grade(String studentName, int grade) {
            this.studentName = studentName;
            this.grade = grade;
        }
        
        @Override
        public String toString() {
            return studentName + ": " + grade;
        }
    }

    // List to store grades
    private List<Grade> grades = new ArrayList<>();
    
    // Method to assign a grade to a student
    public void assignGrade(String studentName, int grade) {
        if (grade < 0 || grade > 100) {
            throw new IllegalArgumentException("Invalid grade: " + grade);
        }
        grades.add(new Grade(studentName, grade));
    }
    
    public static void main(String[] args) {
        SchoolManagementSystem system = new SchoolManagementSystem();
        
        // Try to assign valid and invalid grades
        try {
            system.assignGrade("Alice", 95);
            System.out.println("Successfully assigned a grade to Alice.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Attempted to assign grade to Alice.");
        }
        
        try {
            system.assignGrade("Bob", 105); // This should fail
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Attempted to assign grade to Bob.");
        }
        
        // Output the grades list
        System.out.println("All grades:");
        system.grades.forEach(System.out::println);
    }
}
 /*@author 136201
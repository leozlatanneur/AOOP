/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulation;

/**
 *
 * @author admin
 */
public class Patient extends person {
    private String condition;

    public Patient() {}

    public Patient(String name, int age, String condition) {
        super(name, age);
        this.condition = condition;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    @Override
    protected void displayDetails() {
        super.displayDetails();
        System.out.println("Condition: " + condition);
    }
}

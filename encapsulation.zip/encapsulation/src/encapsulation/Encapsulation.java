/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulation;

/**
 *
 * @author admin
 */
public class Encapsulation {
    public static void main(String[] args) {
        Doctor doctor = new Doctor("Dr. leo mutiki kizito", 45, "Cardiology");
        Patient patient = new Patient("wairimu", 37, "flu");

        Hospital hospital = new Hospital();
        hospital.setDoctor(doctor);
        hospital.setPatient(patient);

        hospital.displayHospitalDetails();
    }
}

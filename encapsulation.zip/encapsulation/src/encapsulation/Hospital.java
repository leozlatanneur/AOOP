/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulation;

/**
 *
 * @author admin
 */
public class Hospital {
    private Doctor doctor;
    private Patient patient;

    public Hospital() {}

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Patient getPatient() {
        return patient;
    }

    public void displayHospitalDetails() {
        System.out.println("Hospital Details:");
        if (doctor != null) {
            System.out.println("-- Doctor --");
            doctor.displayDetails();
        }
        if (patient != null) {
            System.out.println("-- Patient --");
            patient.displayDetails();
        }
    }
}

